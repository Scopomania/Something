package com.danmod.loadinglog.mixin;

import com.danmod.loadinglog.LogOverlayRenderer;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraftforge.fml.earlydisplay.EarlyLoadingScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = EarlyLoadingScreen.class, remap = false)
public class EarlyLoadingScreenMixin {

    /**
     * Injects at the end of the render method so our overlay
     * draws on top of Forge's default loading screen content.
     *
     * EarlyLoadingScreen.render() is called every frame during boot.
     * We piggyback here to draw the scrolling log panel on the left.
     */
    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(CallbackInfo ci) {
        LogOverlayRenderer.render();
    }
}
