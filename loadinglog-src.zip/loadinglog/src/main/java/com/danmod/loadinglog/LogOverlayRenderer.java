package com.danmod.loadinglog;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.gui.Font;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Renders a scrolling log overlay on the left side of the screen
 * during Forge's early loading phase.
 *
 * Panel occupies roughly the left 30% of the screen — the same
 * empty black area visible in the PojavLauncher boot screenshots.
 *
 * Text style mirrors the "Mod loading complete - 42 mods loaded"
 * line: monospace-style, small white text on a semi-transparent
 * dark background.
 */
public class LogOverlayRenderer {

    // Max lines kept in memory (ring buffer)
    private static final int MAX_LINES = 200;
    // How many lines to show on screen at once
    private static final int VISIBLE_LINES = 18;

    private static final Deque<String> lines = new ArrayDeque<>();

    // Panel geometry (fractions of screen, set in render())
    private static final float PANEL_LEFT_FRAC   = 0.01f;
    private static final float PANEL_TOP_FRAC    = 0.15f;
    private static final float PANEL_RIGHT_FRAC  = 0.30f;
    private static final float PANEL_BOTTOM_FRAC = 0.90f;

    // Colors
    private static final int BG_COLOR   = 0xBB000000; // semi-transparent black
    private static final int TEXT_COLOR = 0xFFCCCCCC; // light grey, same tone as Forge status text
    private static final int BORDER_COLOR = 0xFF444444;

    /** Called from the StartupMessageManager mixin — thread-safe append. */
    public static synchronized void addLine(String message) {
        if (message == null || message.isBlank()) return;
        lines.addLast(message);
        while (lines.size() > MAX_LINES) {
            lines.pollFirst();
        }
    }

    /**
     * Called every frame from EarlyLoadingScreenMixin.
     * At this point the early GL context is active but Minecraft's
     * full font system may not be ready, so we fall back to a
     * lightweight immediate-mode draw if needed.
     */
    public static void render() {
        try {
            renderImpl();
        } catch (Exception ignored) {
            // Never crash the loading screen
        }
    }

    private static void renderImpl() {
        // Grab screen dimensions from the current framebuffer size.
        // During early loading, Minecraft.getInstance() may exist but
        // getWindow() is the safest path.
        int sw, sh;
        try {
            sw = Minecraft.getInstance().getWindow().getGuiScaledWidth();
            sh = Minecraft.getInstance().getWindow().getGuiScaledHeight();
        } catch (Exception e) {
            return; // Window not ready yet
        }

        int panelLeft   = (int)(sw * PANEL_LEFT_FRAC);
        int panelTop    = (int)(sh * PANEL_TOP_FRAC);
        int panelRight  = (int)(sw * PANEL_RIGHT_FRAC);
        int panelBottom = (int)(sh * PANEL_BOTTOM_FRAC);
        int panelW = panelRight - panelLeft;
        int panelH = panelBottom - panelTop;

        // ── Draw background quad ──────────────────────────────────────
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();

        Tesselator tess = Tesselator.getInstance();
        BufferBuilder buf = tess.getBuilder();

        // Background
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        fillRect(buf, panelLeft, panelTop, panelRight, panelBottom, BG_COLOR);
        tess.end();

        // Border (1px lines — draw as thin quads)
        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        fillRect(buf, panelLeft,     panelTop,    panelRight,    panelTop + 1,    BORDER_COLOR);
        fillRect(buf, panelLeft,     panelBottom, panelRight,    panelBottom + 1, BORDER_COLOR);
        fillRect(buf, panelLeft,     panelTop,    panelLeft + 1, panelBottom,     BORDER_COLOR);
        fillRect(buf, panelRight,    panelTop,    panelRight + 1,panelBottom,     BORDER_COLOR);
        tess.end();

        // ── Draw text ─────────────────────────────────────────────────
        Font font;
        try {
            font = Minecraft.getInstance().font;
            if (font == null) return;
        } catch (Exception e) {
            return;
        }

        // Snapshot the last VISIBLE_LINES entries
        List<String> snapshot;
        synchronized (LogOverlayRenderer.class) {
            snapshot = new ArrayList<>(lines);
        }
        int start = Math.max(0, snapshot.size() - VISIBLE_LINES);
        List<String> visible = snapshot.subList(start, snapshot.size());

        int lineHeight = font.lineHeight + 2;
        int textX = panelLeft + 4;
        int textY = panelBottom - 4 - (visible.size() * lineHeight); // pin to bottom

        PoseStack ps = new PoseStack();
        for (String line : visible) {
            // Clip to panel width
            String clipped = clipToWidth(font, line, panelW - 8);
            font.draw(ps, clipped, textX, textY, TEXT_COLOR);
            textY += lineHeight;
        }

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private static void fillRect(BufferBuilder buf,
                                  int x0, int y0, int x1, int y1,
                                  int color) {
        float a = ((color >> 24) & 0xFF) / 255f;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >>  8) & 0xFF) / 255f;
        float b = ( color        & 0xFF) / 255f;
        buf.vertex(x0, y1, 0).color(r, g, b, a).endVertex();
        buf.vertex(x1, y1, 0).color(r, g, b, a).endVertex();
        buf.vertex(x1, y0, 0).color(r, g, b, a).endVertex();
        buf.vertex(x0, y0, 0).color(r, g, b, a).endVertex();
    }

    private static String clipToWidth(Font font, String text, int maxWidth) {
        if (font.width(text) <= maxWidth) return text;
        // Binary-search trim
        int len = text.length();
        while (len > 0 && font.width(text.substring(0, len) + "…") > maxWidth) {
            len--;
        }
        return text.substring(0, len) + "…";
    }
}
