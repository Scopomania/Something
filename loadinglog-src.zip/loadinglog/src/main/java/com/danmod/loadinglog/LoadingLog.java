package com.danmod.loadinglog;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Mod(LoadingLog.MOD_ID)
public class LoadingLog {
    public static final String MOD_ID = "loadinglog";
    public static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    public LoadingLog() {
        FMLJavaModLoadingContext.get().getModEventBus()
            .addListener(this::onClientSetup);
    }

    private void onClientSetup(FMLClientSetupEvent event) {
        LOGGER.info("LoadingLog overlay initialized.");
    }
}
