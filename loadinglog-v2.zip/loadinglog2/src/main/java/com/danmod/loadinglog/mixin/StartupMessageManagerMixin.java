package com.danmod.loadinglog.mixin;

import com.danmod.loadinglog.LogOverlayRenderer;
import net.minecraftforge.fml.loading.progress.StartupMessageManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = StartupMessageManager.class, remap = false)
public abstract class StartupMessageManagerMixin {

    @Inject(method = "addModMessage", at = @At("HEAD"))
    private static void onModMessage(String message, CallbackInfo ci) {
        LogOverlayRenderer.addLine(message);
    }

    @Inject(method = "addForgeMessage", at = @At("HEAD"))
    private static void onForgeMessage(String message, CallbackInfo ci) {
        LogOverlayRenderer.addLine("[Forge] " + message);
    }
}
