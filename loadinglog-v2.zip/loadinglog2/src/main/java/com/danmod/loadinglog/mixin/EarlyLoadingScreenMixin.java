package com.danmod.loadinglog.mixin;

import com.danmod.loadinglog.LogOverlayRenderer;
import net.minecraftforge.fml.earlydisplay.EarlyLoadingScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = EarlyLoadingScreen.class, remap = false)
public abstract class EarlyLoadingScreenMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(CallbackInfo ci) {
        LogOverlayRenderer.render();
    }
}
