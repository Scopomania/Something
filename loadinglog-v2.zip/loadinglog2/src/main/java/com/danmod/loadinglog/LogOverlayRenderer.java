package com.danmod.loadinglog;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

public class LogOverlayRenderer {

    private static final int MAX_LINES = 200;
    private static final int VISIBLE_LINES = 18;
    private static final Deque<String> lines = new ArrayDeque<>();
    private static final List<String> earlyBuffer = new ArrayList<>();
    private static boolean fontReady = false;

    private static final float PANEL_LEFT_FRAC   = 0.01f;
    private static final float PANEL_TOP_FRAC    = 0.15f;
    private static final float PANEL_RIGHT_FRAC  = 0.30f;
    private static final float PANEL_BOTTOM_FRAC = 0.90f;

    private static final int BG_COLOR     = 0xBB000000;
    private static final int TEXT_COLOR   = 0xFFCCCCCC;
    private static final int BORDER_COLOR = 0xFF444444;

    public static synchronized void addLine(String message) {
        if (message == null || message.isBlank()) return;
        if (!fontReady) {
            earlyBuffer.add(message);
            return;
        }
        lines.addLast(message);
        while (lines.size() > MAX_LINES) lines.pollFirst();
    }

    public static void render() {
        try { renderImpl(); } catch (Exception ignored) {}
    }

    private static void renderImpl() {
        int sw, sh;
        try {
            sw = Minecraft.getInstance().getWindow().getGuiScaledWidth();
            sh = Minecraft.getInstance().getWindow().getGuiScaledHeight();
        } catch (Exception e) { return; }

        int panelLeft   = (int)(sw * PANEL_LEFT_FRAC);
        int panelTop    = (int)(sh * PANEL_TOP_FRAC);
        int panelRight  = (int)(sw * PANEL_RIGHT_FRAC);
        int panelBottom = (int)(sh * PANEL_BOTTOM_FRAC);
        int panelW = panelRight - panelLeft;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();

        Tesselator tess = Tesselator.getInstance();
        BufferBuilder buf = tess.getBuilder();

        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        fillRect(buf, panelLeft, panelTop, panelRight, panelBottom, BG_COLOR);
        tess.end();

        buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        fillRect(buf, panelLeft,  panelTop,    panelRight,     panelTop + 1,    BORDER_COLOR);
        fillRect(buf, panelLeft,  panelBottom, panelRight,     panelBottom + 1, BORDER_COLOR);
        fillRect(buf, panelLeft,  panelTop,    panelLeft + 1,  panelBottom,     BORDER_COLOR);
        fillRect(buf, panelRight, panelTop,    panelRight + 1, panelBottom,     BORDER_COLOR);
        tess.end();

        var font = Minecraft.getInstance().font;
        if (font == null) return;

        synchronized (LogOverlayRenderer.class) {
            if (!fontReady) {
                fontReady = true;
                for (String s : earlyBuffer) {
                    lines.addLast(s);
                    while (lines.size() > MAX_LINES) lines.pollFirst();
                }
                earlyBuffer.clear();
            }
        }

        List<String> snapshot;
        synchronized (LogOverlayRenderer.class) {
            snapshot = new ArrayList<>(lines);
        }
        int start = Math.max(0, snapshot.size() - VISIBLE_LINES);
        List<String> visible = snapshot.subList(start, snapshot.size());

        int lineHeight = font.lineHeight + 2;
        int textX = panelLeft + 4;
        int textY = panelBottom - 4 - (visible.size() * lineHeight);

        PoseStack ps = new PoseStack();
        for (String line : visible) {
            String clipped = clipToWidth(font, line, panelW - 8);
            font.draw(ps, Component.literal(clipped), (float) textX, (float) textY, TEXT_COLOR);
            textY += lineHeight;
        }

        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    private static void fillRect(BufferBuilder buf, int x0, int y0, int x1, int y1, int color) {
        float a = ((color >> 24) & 0xFF) / 255f;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >>  8) & 0xFF) / 255f;
        float b = ( color        & 0xFF) / 255f;
        buf.vertex(x0, y1, 0).color(r, g, b, a).endVertex();
        buf.vertex(x1, y1, 0).color(r, g, b, a).endVertex();
        buf.vertex(x1, y0, 0).color(r, g, b, a).endVertex();
        buf.vertex(x0, y0, 0).color(r, g, b, a).endVertex();
    }

    private static String clipToWidth(net.minecraft.client.gui.Font font, String text, int maxWidth) {
        if (font.width(text) <= maxWidth) return text;
        int len = text.length();
        while (len > 0 && font.width(text.substring(0, len) + "…") > maxWidth) len--;
        return text.substring(0, len) + "…";
    }
}
